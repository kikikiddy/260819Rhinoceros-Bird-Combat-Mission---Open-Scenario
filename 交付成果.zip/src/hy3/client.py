"""Hy3 调用骨架（T02）。

OpenAI 兼容客户端封装：
- 配置全部来自环境变量，绝不硬编码密钥；
- 内置超时 / 指数退避重试 / 最小调用间隔（简易限流）/ 结构化日志；
- 支持 Hy3 的 reasoning_effort（no_think / low / high），默认 no_think 直出以保证审阅响应稳定。

环境变量：
    HY3_API_KEY   Hy3 API Key，本地自部署默认 "EMPTY"（可省略）
    HY3_BASE_URL  OpenAI 兼容端点，默认 http://127.0.0.1:8000/v1
    HY3_MODEL     模型名，默认 "hy3"
    HY3_TIMEOUT   单次请求超时秒数，默认 60
    HY3_MAX_RETRIES 失败重试次数，默认 3
    HY3_MIN_INTERVAL 两次调用最小间隔秒数（简易限流），默认 0.2
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass
from typing import Any, Iterable

from openai import APIConnectionError, APIError, APITimeoutError, RateLimitError

# 启动时尽量加载 .env（本地配置端点用），缺失 dotenv 则静默跳过
try:
    from dotenv import load_dotenv

    load_dotenv()
except Exception:  # noqa: BLE001
    pass

logger = logging.getLogger("hy3")

DEFAULTS = {
    "api_key": "EMPTY",
    "base_url": "http://127.0.0.1:8000/v1",
    "model": "hy3",
    "timeout": 60,
    "max_retries": 3,
    "min_interval": 0.2,
    "temperature": 0.9,
    "top_p": 1.0,
}

RETRYABLE = (APIConnectionError, APITimeoutError, RateLimitError)


@dataclass
class Hy3Config:
    api_key: str
    base_url: str
    model: str
    timeout: int
    max_retries: int
    min_interval: float

    @classmethod
    def from_env(cls) -> "Hy3Config":
        return cls(
            api_key=os.getenv("HY3_API_KEY", DEFAULTS["api_key"]),
            base_url=os.getenv("HY3_BASE_URL", DEFAULTS["base_url"]),
            model=os.getenv("HY3_MODEL", DEFAULTS["model"]),
            timeout=int(os.getenv("HY3_TIMEOUT", DEFAULTS["timeout"])),
            max_retries=int(os.getenv("HY3_MAX_RETRIES", DEFAULTS["max_retries"])),
            min_interval=float(os.getenv("HY3_MIN_INTERVAL", DEFAULTS["min_interval"])),
        )

    def safe_summary(self) -> dict[str, Any]:
        """对外暴露不含密钥的摘要，避免日志/报告泄露。"""
        return {
            "base_url": self.base_url,
            "model": self.model,
            "timeout": self.timeout,
            "max_retries": self.max_retries,
            "api_key_set": bool(self.api_key) and self.api_key != "EMPTY",
        }


class Hy3Client:
    """Hy3（OpenAI 兼容）客户端，封装重试 / 限流 / 日志。"""

    def __init__(self, config: Hy3Config | None = None):
        self.config = config or Hy3Config.from_env()
        self._last_call_ts = 0.0
        self._client = self._build_client()

    def _build_client(self):
        from openai import OpenAI

        return OpenAI(
            api_key=self.config.api_key,
            base_url=self.config.base_url,
            timeout=self.config.timeout,
        )

    def chat(
        self,
        messages: list[dict[str, str]],
        *,
        temperature: float = DEFAULTS["temperature"],
        top_p: float = DEFAULTS["top_p"],
        reasoning_effort: str = "no_think",
        max_tokens: int | None = None,
    ) -> str:
        """调用 Hy3 chat completions，返回助手文本。

        reasoning_effort:
            no_think -> 直接回复（默认，审阅稳定）
            low      -> 轻度思考
            high     -> 深度思考
        """
        cfg = self.config
        extra_body = {"chat_template_kwargs": {"reasoning_effort": reasoning_effort}}
        kwargs: dict[str, Any] = {
            "model": cfg.model,
            "messages": messages,
            "temperature": temperature,
            "top_p": top_p,
            "extra_body": extra_body,
        }
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens

        self._respect_rate_limit()
        last_err: Exception | None = None
        for attempt in range(1, cfg.max_retries + 2):  # 1 次初试 + N 次重试
            try:
                resp = self._client.chat.completions.create(**kwargs)
                content = resp.choices[0].message.content or ""
                logger.info(
                    "hy3 chat ok attempt=%d effort=%s chars=%d", attempt, reasoning_effort, len(content)
                )
                return content
            except RETRYABLE as e:
                last_err = e
                wait = min(2 ** (attempt - 1), 8)
                logger.warning("hy3 retryable error attempt=%d wait=%ss: %s", attempt, wait, e)
                if attempt <= cfg.max_retries:
                    time.sleep(wait)
                continue
            except APIError as e:
                # 非可重试的 API 错误，直接抛出，避免无效重试
                logger.error("hy3 api error: %s", e)
                raise
        raise RuntimeError(f"hy3 chat failed after {cfg.max_retries + 1} attempts") from last_err

    def _respect_rate_limit(self):
        gap = time.time() - self._last_call_ts
        if gap < self.config.min_interval:
            time.sleep(self.config.min_interval - gap)
        self._last_call_ts = time.time()


def configure_logging(level: int = logging.INFO) -> None:
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s %(name)s | %(message)s",
    )
